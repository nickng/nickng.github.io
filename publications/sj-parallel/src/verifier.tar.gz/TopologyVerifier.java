package sessionj.verifier;

import org.ho.yaml.*;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Topology verifier class
 */
public class TopologyVerifier {
    public static boolean topologyValid = true; // Topology is by default correct
    public static String startHost = null; // Host with only outgoing connections
    public static String endHost = null;   // Host with only incoming connections
    public static Map<String, Map<String, Object>> hosts = null;
    
    public static void main(String[] args) throws Exception {

        if (args.length < 1) {
            System.err.println("Error: Not enough arguments (want=1, got="+args.length+")");
            System.exit(1);
        }

        hosts = (Map<String, Map<String, Object>>) Yaml.load(new File(args[0]));

        TopologyVerifier.findGoals();

        if (!TopologyVerifier.topologyValid) {
            System.err.println("Not a valid topology (Reason: Unable to identify coordinating host and sink host)");
            System.exit(1);
        }

        System.out.println("- coordinating node="+TopologyVerifier.startHost+" and sink node="+TopologyVerifier.endHost);

        TopologyVerifier.checkRoute();

        System.out.print("The topology is ");
        System.out.println(TopologyVerifier.topologyValid ? "valid" : "invald" );

        // Checked
        if (TopologyVerifier.topologyValid) {
            Yaml.dump(hosts, new File(args[0]+".generated"));
            System.out.println("Topology verified and conforms to well-formed topology. Intermediate yaml generated.");
        } else {
            System.out.println("Topology does NOT conform to well-formed topology.");
        }

    }
    
    /**
     * Finds the <tt>startHost</tt> and the <tt>endHost</tt>.
     */
    public static void findGoals() {
        Map<String, Map<String, Object>> hosts = TopologyVerifier.hosts;

        for (String key: hosts.keySet()) {
            Map<String, Object> host = hosts.get(key);
            
            if (host.get("client") == null && TopologyVerifier.endHost == null) {
                TopologyVerifier.endHost = key;
                continue;
            }

            if (host.get("server") == null && TopologyVerifier.startHost == null) {
                TopologyVerifier.startHost = key;
                continue;
            }

            // Any extra source/destination = cannot be topology,
            // for a single group of hosts
            // 
            if (host.get("server") == null || host.get("client") == null) {
                System.err.println("Error: "+key+" is an invalid entry (Reason: multiple coordinating/sink nodes");
                TopologyVerifier.topologyValid = false;
            }
        }
    }

    /**
     * Check all routes from coordinating node can reach sink node.
     */
    public static void checkRoute() {
        //
        // Next we run a BFS on source and see if all routes started from
        // coordinating host goes to sink host
        //

        Set<String> visited = new HashSet<String>();
        Map<String, Integer> visitedLevel = new HashMap<String, Integer>();
        int currentLevel = 0;
        Queue<String> queue = new LinkedList<String>();;

        queue.offer(TopologyVerifier.startHost);

        while (queue.size() > 0) {
            ++currentLevel;
            String head = queue.remove();
            System.out.println("- Visiting "+head);
            visited.add(head);
            visitedLevel.put(head, currentLevel);

            if (head.equals(TopologyVerifier.endHost)) continue; // Don't need to look at children
                
            Map<String, Object> headNode = hosts.get(head);
            if (headNode == null) {
                System.err.println("Error: Unknown node name "+head);
                TopologyVerifier.topologyValid = false;
                break;
            }
            List<Map<String, String>> clients = (List<Map<String, String>>) headNode.get("client");
            
            // Expected early termination
            if (clients == null) {
                System.err.println("Error: Invalid topology: "+head+" does not relay to "+TopologyVerifier.endHost);
                TopologyVerifier.topologyValid = false;
                break;
            }

            // Unidirection
            for(Map<String, String> client: clients) {
                String next = client.containsKey("host") ? client.get("host") : client.get("service").split("@")[1];
                if (visited.contains(next) && visitedLevel.get(next) < currentLevel) {
                    System.err.println("Error: Invalid topology: "+head+" has a loop with previous level ("+next+")");
                    TopologyVerifier.topologyValid = false;
                    break;
                }

                // Only enqueue once; if they are in the queue they are forward-cycles
                if (!queue.contains(next)) {
                    queue.offer(next);
                }
            }

            System.err.println("- Current level/queue:"+currentLevel+" "+queue);

        }

        if (visited.size() != TopologyVerifier.hosts.size()) {
            System.err.println("Warning: Not all nodes defined are used in the configuration.");
        }

        // Ordering within ranks
        //
        List<String> indexedProcesses = new LinkedList<String>();
        for (int rank=1; visitedLevel.containsValue(rank); ++rank) {
            for (String node: visitedLevel.keySet()) {
                if (visitedLevel.get(node).equals(rank))
                    indexedProcesses.add(node);
            }
        }

        // Extract protocol
        //
        for (int index=0; index<indexedProcesses.size(); ++index) {
            String nodeName = indexedProcesses.get(index);
            Map<String, Object> host = hosts.get(nodeName);
            List<Map<String, String>> clients = (List<Map<String, String>>)host.get("client");

            host.put("processIndex", index+1);

            if (clients == null) continue; // We don't look at sinks

            for (Map<String, String> client: clients) {
                String serverName  = client.containsKey("host") ? client.get("host")    : client.get("service").split("@")[1];
                String serviceName = client.containsKey("host") ? client.get("service") : client.get("service").split("@")[0];
                int theirIndex = indexedProcesses.indexOf(serverName);
                if (theirIndex != -1) {
                    client.put("channelName", (index+1)+","+(theirIndex+1));
                } else {
                    System.err.println("Warning: could not work out channel names.");
                }

                List<Map<String, String>> servers =  (List<Map<String, String>>)hosts.get(serverName).get("server");
                for (Map<String, String> server: servers) {
                    if (serviceName.equals(server.get("name"))) {
                        server.put("channelName", (index+1)+","+(theirIndex+1));
                    }
                }
            }
        }
    }

}
