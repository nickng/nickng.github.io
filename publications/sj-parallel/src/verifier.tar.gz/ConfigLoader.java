package sessionj.verifier;

import org.ho.yaml.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Helper class to load configuration file in an SJ program.
 * Example usage:
 * With a properly defined config.yaml, Master node in a ring topology:
 *
 * $ sessionj -cp jyaml-1.3.jar:. Master ring.yaml master arg0 arg1 ...
 *
 * import ConfigLoader;
 * ...
 * public static void main(String[] args) throws Exception {
 *   ConfigLoader config = ConfigLoader.load(args[0], args[1]);
 *   String nextHost = config.get("s1.host");
 *   int nextPort = Integer.parseInt(config.get("s1.port"));
 *   String lastHost = config.get("s2.host");
 *   int lastPort = Integer.parseInt(config.get("s1.port"));
 *
 *   ... other arguments ...
 *
 *   master.run(nextHost, nextPort, lastHost, lastPort, arg0, arg1, ... );
 * }
 */
public class ConfigLoader {
    protected Map<String, Map<String, String>> _data;
    private static final ConfigLoader _mInstance = new ConfigLoader();
    /**
     * private Ctor
     */
    private ConfigLoader() {}

    /**
     * Entry point
     */
    public static ConfigLoader load(String filename, String host) throws FileNotFoundException {
        Map<String, Map<String, List<Map<String, String>>>> yamlConfig 
            = (Map<String, Map<String, List<Map<String, String>>>>) Yaml.load(new File(filename));

        // Load yaml in memory, also add/modifies get() target for easy
        // access to common options (ie. host, port etc.)
        // 
        ConfigLoader._mInstance._data = new HashMap<String, Map<String, String>>();
        if (yamlConfig.containsKey(host)) {
            List<Map<String, String>> serverKVs = yamlConfig.get(host).get("server");
            if (serverKVs != null) {
                for (Map<String, String> serverKV: serverKVs) {
                    // Just port for now, we expect all the hosts to be localhost (don't have RMI support yet)
                    serverKV.put("port", serverKV.get("socket").split(":\\/?\\/?")[2]);
                    ConfigLoader._mInstance._data.put(serverKV.get("name"), serverKV);
                }
            }
            List<Map<String, String>> clientKVs = yamlConfig.get(host).get("client");
            if (clientKVs != null) {
                for (Map<String, String> clientKV: clientKVs) {
                    try {
                        // service signature: service@hostname
                        String[] svcSig = clientKV.get("service").split("@");
                        try {
                            List<Map<String, String>> serverAttrs = yamlConfig.get(svcSig[1]).get("server");
                            for (Map<String, String> serverAttr: serverAttrs) {

                                // Lookup server "service" to extract client IP/hostname port pair.
                                if (serverAttr.get("name").equals(svcSig[0])) {
                                    String[] socket = serverAttr.get("socket").split(":\\/?\\/?");
                                    Map<String, String> clientAttr = new HashMap<String, String>();
                                    clientAttr.put("proto", socket[0]);
                                    clientAttr.put("host",  socket[1]);
                                    clientAttr.put("port",  socket[2]);
                                    ConfigLoader._mInstance._data.put(clientKV.get("name"), clientAttr);
                                    break;
                                }

                            }
                        } catch (NullPointerException npe) {
                            // This should not happen if the yaml is correctly defined
                            // (ie. no dangling client, server)
                            System.err.println("Error: Unable to extract address/port for service "
                                +svcSig[0]+" on "+svcSig[1]+". Entry skipped.");
                        }
                    } catch (ArrayIndexOutOfBoundsException aioobe) {
                        System.err.println("Error: Unable to extract service/host from service string "
                            + clientKV.get("service") + " (Are you using { service=svc@host } format?). "
                            + "Entry skipped.");
                    }
                }
            }
        } else {
            System.err.println("Warning: Nothing loaded (reason: "+host+" not found "
                               + "in configuration file "+filename+")");
        }

        return ConfigLoader._mInstance;
    }

    /**
     * Fetches an attribute from the loaded configuration file.
     *
     * @param chnlName name of the socket
     * @param attrName name of the attribute (eg. host, port)
     */
    public String get(String chnlName, String attrName) {
        if (_data.containsKey(chnlName) && _data.get(chnlName).containsKey(attrName)) {
                return _data.get(chnlName).get(attrName);
        }

        System.err.println("Warning: Attribute "+chnlName+"."+attrName+" not found");
        return "";
    }

    /**
     * Shorthand version of get(chnlName, attrName).
     *
     * @param resource is chnlName.attrName (eg. prev.host)
     */
    public String get(String resource) {
        String[] parts = resource.split("\\.");
        if (parts.length > 2) {
            System.err.println("Warning: Attribute '"+resource+"' has more than 2 components. "
                               + "Only using '"+parts[0]+"."+parts[parts.length-1]+"'.");
        }

        return get(parts[0], parts[parts.length-1]);
    }
}
